﻿namespace Classifieds.Web.Constants
{
    public static class Policies
    {
        public const string IsMinimumAge = "MinimumAge";
    }
}
