﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Classifieds.Web.Constants
{
    public static class UserClaims
    {
        public const string isMinimumAge = "isMinimumAge";
        public const string FullName = "fullName";
    }
}
